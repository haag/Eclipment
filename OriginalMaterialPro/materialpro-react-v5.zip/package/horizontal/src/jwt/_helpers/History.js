import { createBrowserHistory } from "history";

export const History = createBrowserHistory({ basename: "/" });
